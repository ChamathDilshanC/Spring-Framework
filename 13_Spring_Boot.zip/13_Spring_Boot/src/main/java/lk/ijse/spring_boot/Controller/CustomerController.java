package lk.ijse.spring_boot.Controller;

import lk.ijse.spring_boot.dto.CustomerDTO;
import lk.ijse.spring_boot.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/customer")
public class CustomerController {
    // Property Injection
    @Autowired
    private CustomerService customerService;

    @GetMapping(path = "getAll")
    public String getCustomer(){
        return "Hello Spring Boot";
    }

    @PostMapping(path = "save" , consumes = "application/json")
    public String saveCustomer(@RequestBody CustomerDTO customerDTO){
        boolean b = customerService.addCustomer(customerDTO);
        return b+"";
    }

}

package lk.ijse.spring_boot.service;

import lk.ijse.spring_boot.Repo.CustomerRepo;
import lk.ijse.spring_boot.dto.CustomerDTO;
import lk.ijse.spring_boot.entity.Customer;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
    private CustomerRepo customerRepo;
    public CustomerService() {
        System.out.println("CustomerService Instantiated...");
    }

    public boolean addCustomer(CustomerDTO customerDTO){
        Customer customer = new Customer(customerDTO.getId(), customerDTO.getName(), customerDTO.getAddress());
        // data Saving
        customerRepo.save(customer);
        return true;
    }

}

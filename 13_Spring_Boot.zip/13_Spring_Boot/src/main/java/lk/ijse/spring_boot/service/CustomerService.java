package lk.ijse.spring_boot.service;

import lk.ijse.spring_boot.dto.CustomerDTO;

import java.util.List;

public interface CustomerService {
    boolean addCustomer(CustomerDTO customerDTO);
    List<CustomerDTO> getAllCustomers();
    boolean updateCustomer(CustomerDTO customerDTO);
    boolean deleteCustomer(String id);
}
